from .clara_gen50layer import  EdgeEstimator 
